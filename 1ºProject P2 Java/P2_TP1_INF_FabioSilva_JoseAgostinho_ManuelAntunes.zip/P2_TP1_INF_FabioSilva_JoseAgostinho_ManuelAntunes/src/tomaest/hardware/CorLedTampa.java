package tomaest.hardware;

/** enumera��o com as cores poss�veis para os leds das tampas
 * @author F. S�rgio Barbosa
 */
public enum CorLedTampa {
	OFF, GREEN, YELLOW, RED;
}
