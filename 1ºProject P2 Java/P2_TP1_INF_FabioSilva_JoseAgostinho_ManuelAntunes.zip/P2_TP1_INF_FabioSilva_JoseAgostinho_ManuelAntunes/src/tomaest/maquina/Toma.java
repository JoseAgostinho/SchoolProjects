package tomaest.maquina;

import java.time.LocalDateTime;

/** Representa uma toma, isto �, quais os medicamentos e a quantidade de cada um
 *  que se tem de tomar numa dada data.
 */
public class Toma {
	private LocalDateTime quando;
	private TomaParcial partes; 
	
	public Toma (TomaParcial partes , LocalDateTime quando) {
		setQuando(quando);
		setPartes(partes);
	}
	
	public LocalDateTime getQuando() {
		return quando;
	}

	public void setQuando(LocalDateTime quando) {
		this.quando = quando;
	}

	public TomaParcial getPartes() {
		return partes;
	}

	public void setPartes(TomaParcial partes) {
		this.partes = partes;
	}
	
}
