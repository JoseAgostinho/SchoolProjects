package tomaest.maquina;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import tomaest.hardware.CorLedTampa;
import tomaest.hardware.Hardware;

/** Classe que representa o software de controlo da m�quina dispensadora.
 * Esta classe deve fornecer m�todos para a comunica��o com a PhoneApp e
 * deve ela pr�pria comunicar com o hardware.
 */
public class Maquina {

	private Hardware hardware; // hardware da m�quina que vai controlar

	//----------Vars-----------//
	private Toma toma;
	private Dispensador dispensador;
	private int vezesProcessou = 0;
	//-----------------------//
	//-------Listas---------//
	private List <Dispensador> listaDispensadores = new ArrayList <Dispensador>();
	private List <Toma> listaTomas = new ArrayList <Toma>();
	//---------------------//


	//1�Construtor
	/** cria uma m�quina com o respetivo hardware 
	 * @param hardware hardware da m�quina que vai controlar
	 */
	public Maquina(Hardware hardware) {
		this.hardware = hardware;
		hardware.setMaquina( this );
	}

	public Hardware getHardware() {
		return hardware;
	}

	public void setHardware(Hardware hardware) {
		this.hardware = hardware;
	}

	public Toma getToma() {
		return toma;
	}

	public void setToma(Toma toma) {
		this.toma = toma;
	}

	public Dispensador getDispensador() {
		return dispensador;
	}

	public void setDispensador(Dispensador dispensador) {
		this.dispensador = dispensador;
	}

	public List<Dispensador> getListaDispensadores() {
		return listaDispensadores;
	}

	public void setListaDispensadores(List<Dispensador> listaDispensadores) {
		this.listaDispensadores = listaDispensadores;
	}

	public List<Toma> getListaTomas() {
		return listaTomas;
	}

	public void setListaTomas(List<Toma> listaTomas) {
		this.listaTomas = listaTomas;
	}

	/** m�todo que � chamado pelo temporizador do hardware
	 * sempre que se passam 20 segundos
	 */
	public void processar() {	
			if(checkTomas()) {		
				vezesProcessou ++;
				if (vezesProcessou != 0 && vezesProcessou % 3 == 0 && vezesProcessou <= 15) {  //para tocar o alarme de 1 em 1 minuto durante 5 minutos 
					for (Toma toma : listaTomas) {
						for(Dispensador d : listaDispensadores) {
							if (toma.getPartes().getDispensador().getNumeroDispensador()==d.getNumeroDispensador()) {			//para usar no despejar
								int quantDesp = toma.getPartes().getnComprimidosUsar();												//para usar no despejar
								hardware.abrirGaveta();
								hardware.tocaAlarme();
								d.despeja(quantDesp);																				//retira comprimidos do dispensador
							}
						}
					}
				}
				if  (vezesProcessou > 15) {													//se ultrapassa os 5 min para tocar de 20 em 20 segundos
					hardware.abrirGaveta();
					hardware.tocaAlarme();
				}
			}else {
				vezesProcessou = 0 ;
			}
		}

	/** m�todo que � chamado pelo hardware quando o utente
	 *  removeu os comprimidos da gaveta
	 */
	public void gavetaVazia() {
		hardware.fecharGaveta();
	}


	/** m�todo que vai verificar se h� tomas que t�m
	 * de ser ministradas neste momento
	 */
		private boolean checkTomas() {			//mudado de void para boolean
			LocalDateTime agora = LocalDateTime.now();
			for (Toma t : listaTomas) {
				t.getQuando().compareTo(agora);
				return true;
			}
			return false;
		}	




	/** Indica quantos dispensadores horizontais existem
	 * @return n�mero de dispensadores horizontais
	 */
	public int getDispensadoresHorizontais() {
		return hardware.getHorizontais();
	}

	/** Indica quantos dispensadores verticais existem
	 * @return n�mero de dispensadores verticais
	 */
	public int getDispensadoresVerticais() {
		return hardware.getVerticais();
	}

	/** Abre o dispensador indicado
	 * @param disp n�mero do dispensador a abrir
	 */
	public void abrirDispensador( int disp ) {
		hardware.abrirTampa(disp);
	}

	//Novo Metodo para fechar a tampa do dispensador usado no PhoneApp
	public void fecharDispensador (int disp) {
		hardware.fecharTampa (disp);
	}


	/** indica se o diepensador est� livre ou em uso
	 * @param dispNum n�mero do dispensador
	 * @return true, se o dispensador est� livre, false caso esteja em uso
	 */
	public boolean estaLivre( int dispNum ) {
		for (Dispensador d : listaDispensadores) {
			if( dispNum == d.getNumeroDispensador()) {
				if(d.estaUsado() == true)
					return false;
			}
		}
		return true;
	}

	/** indica qual o medicamento que est� associado ao dispensador
	 * @param dispNum  n�mero do dispensador
	 * @return nome do medicamento associado ao dispensador,
	 * null, caso n�o haja medicamento associado
	 */
	public String getMedicamento( int dispNum ) {
		for (Dispensador d : listaDispensadores) {
			if (dispNum == d.getNumeroDispensador()) {				// se encontrou o dispensador
				if (estaLivre(dispNum) == false) 					// se o dispensador tiver ocupado com medicamentos
					return d.getNomeMedicamento();					//devolve o nome do medicamento
			}
		}
		return null;
	}

	/** indica quantos comprimidos ainda tem no dispensador
	 * @param dispNum n�mero do dispensador
	 * @return quantos comprimidos ainda tem no dispensador
	 */
	public int getQuantidade( int dispNum ) {
		int aux = 0;
		for (Dispensador d : listaDispensadores) {
			if (dispNum == d.getNumeroDispensador())
				aux = d.getQuantidade();            
		}
		if (aux > 0)												//se houver comprimidos la dentro 
			return aux;
		return 0;
	}

	/** Configura um dispensador, indicando qual o medicamento a ele associado
	 * e respetiva quantidade de comprimidos
	 * 
	 * @param dispNum n�mero do dispensador
	 * @param medicamento nome do medicamento
	 * @param quant quantidade de comprimidos
	 */
	public void configurarDispensador( int dispNum, String medicamento, int quant ) {
		dispensador = new Dispensador ( medicamento , quant , dispNum);
		listaDispensadores.add(dispensador);
		fecharDispensador (dispNum);
		cores();	
	}

	/** carrega o dispensador com a quantidade de medicamentos indicada
	 * @param dispNum n�mero do dispensador
	 * @param quant quantidade de comprimidos a adicionar
	 */
	public void carregarDispensador(int dispNum, int quant) {
		if (quant >= 0) {
			for ( Dispensador d : listaDispensadores) {
				if (dispNum == d.getNumeroDispensador())
					d.addQuantidade(quant);
			}
		}
		cores();	
	}

	/** Adiciona uma toma � lista de tomas. Se a toma a adicionar tiver a mesma data
	 * que uma toma j� existente, a nova deve ser associada � j� existente.
	 * As tomas devem estar ordenadas por ordem crescente da data de toma.
	 * 
	 * @param quando data a que a toma deve ser efetuada
	 * @param dispNum qual o dispensador a usar
	 * @param quant quantos comprimidos a usar
	 */
	public void addToma(LocalDateTime quando, int dispNum, int quant ) {
		for (Dispensador d : listaDispensadores) {
			if (dispNum == d.getNumeroDispensador()) {
				for (int i = 0 ; i < 14 ; i ++ ) {									//para criar 1 toma para cada dia por 14 dias
					TomaParcial tomaparcial = new TomaParcial(quant, d);			//para ir buscar a tomaParcial
					Toma toma = new Toma (tomaparcial , quando.plusDays(i));                    //cria uma toma
					listaTomas.add(toma);
				}//adiciona uma nova toma a lista
			}
		}
		cores();	
	}


	/** devolve uma lista com as tomas que devem ser realizadas at� � data indicada
	 * @param fim data de fim da pesquisa
	 * @return uma lista com as tomas que devem ser realizadas at� � data indicada
	 */
	public List<Toma> tomasAte( LocalDateTime fim ){
		List<Toma>tomasNovas = new ArrayList<Toma>(); ;
		for ( Toma t : tomasNovas) {
			if(t.getQuando().compareTo(fim) <= 0) {		//se a lista de tomas for igual ou antes da data indicada
				tomasNovas.add(t);
				return tomasNovas;
			}
		}
		return tomasNovas;
	}



	public void cores(){
		for (Dispensador d : listaDispensadores) {
			if(d.consegueResponder(tomasAte(LocalDateTime.now().plusDays(7)))) 
				hardware.turnLed(d.getNumeroDispensador(), CorLedTampa.GREEN);
			if(d.consegueResponder(tomasAte(LocalDateTime.now().plusDays(3)))) 
				hardware.turnLed(d.getNumeroDispensador(), CorLedTampa.YELLOW);
			if(d.consegueResponder(tomasAte(LocalDateTime.now()))) 
				hardware.turnLed(d.getNumeroDispensador(), CorLedTampa.RED);
			if(!d.estaUsado())
				hardware.turnLed(d.getNumeroDispensador(), CorLedTampa.OFF);
		}
	}

}




