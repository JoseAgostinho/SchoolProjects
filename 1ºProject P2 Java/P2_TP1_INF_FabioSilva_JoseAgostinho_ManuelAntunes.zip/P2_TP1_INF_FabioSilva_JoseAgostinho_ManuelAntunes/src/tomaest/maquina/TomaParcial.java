package tomaest.maquina;

/** Classe que representa uma toma parcial, isto �, qual o dispensador
 * e n�mero de comprimidos a usar desse dispensador. A hora a que os comprimidos
 * devem ser tomados � dada pela classe Toma 
 */
public class TomaParcial {
	private int nComprimidosUsar;
	private Dispensador dispensador;

	//1� Construtor
	public TomaParcial (int quant , Dispensador d) {
		setnComprimidosUsar(quant);
		setDispensador(d);
	}

	public int getnComprimidosUsar() {
		return nComprimidosUsar;
	}

	public void setnComprimidosUsar(int nComprimidosUsar) {
		//para evitar numeros de comprimidos negativos
		if ( nComprimidosUsar < 0 )
			this.nComprimidosUsar = 0;
		else
			this.nComprimidosUsar = nComprimidosUsar;
	}

	public Dispensador getDispensador() {
		return dispensador;
	}

	public void setDispensador(Dispensador dispensador) {
			this.dispensador = dispensador;
	
	}

}
