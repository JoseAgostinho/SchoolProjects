package tomaest.maquina;

import java.util.List;


/** 
 * Classe que representa um dos dispensadores da m�quina.
 * Cada dispensador tem um medicamento e v�rios comprimidos (ou c�psulas)
 * desse medicamento
 */
public class Dispensador {

	//Variaveis do dispensador//
	private String nomeMedicamento;
	private int quantidade;
	private int numeroDispensador;
	//------------------------//

	//1�Construtor
	public Dispensador (String medicamento , int quantidade , int numeroDispensador) {
		setNomeMedicamento(medicamento);
		setQuantidade(quantidade);
		setNumeroDispensador(numeroDispensador);
	}

	public String getNomeMedicamento() {
		return nomeMedicamento;
	}

	public void setNomeMedicamento(String nomeMedicamento) {
		this.nomeMedicamento = nomeMedicamento;
	}

	public int getQuantidade() {
		return quantidade;
	}

	public void setQuantidade(int quantidade) {
		//para nao haver quantidade negativa
		if (quantidade<0)
			this.quantidade = 0;
		else
			this.quantidade = quantidade;
	}

	public int getNumeroDispensador() {
		return numeroDispensador;
	}

	public void setNumeroDispensador(int numeroDispensador) {
		//Condi��es para nao haver dispensadores negativos
		if (numeroDispensador < 0 )
			this.numeroDispensador = 0;
		else
			this.numeroDispensador = numeroDispensador;
	}

	/** adiciona numa certa quantidade de comprimidos ao dispensador
	 * @param quant quantidade a adicionar ao dispensador
	 */
	public void addQuantidade(int quant) {
		//Para nao adicionar quantidades Negativas
		if (quant < 0 )
			quant = 0;
		this.quantidade = this.quantidade + quant;
	}

	/** despeja, na gaveta de sa�da, a quantidade solicitada de comprimidos.
	 * @param quant quantidade de comprimidos a despejar
	 * @return a quantidade realmente despejada, pois pode n�o haver quantidade
	 *  suficiente para satisfazer o pedido
	 */
	public int despeja( int quant ) {
		if (quant < 0 )
			quant = 0;
		this.quantidade = this.quantidade-quant;
		return this.quantidade;
	}

	/** indica se este dispensador est� a ser usado ou se est� livre
	 * @return true, se est� a ser usado, false caso esteja livre
	 */
	public boolean estaUsado( ) {
		//se nao tiver associado a nenhum medicamento o dispensador esta livre
		if (nomeMedicamento == null) {
			return false;
		}
		return true;
	}

	/** Indica se o dispensador tem comprimidos suficientes para
	 * satisfazer todas as tomas da lista
	 * @param tomas lista de tomas que � necess�rio satisfazer
	 * @return true, se tem comprimidos suficientes, false caso contr�rio
	 */
	public boolean consegueResponder( List<Toma> tomas ) {
		int aux = 0;
		for (Toma t : tomas) {
			aux = t.getPartes().getnComprimidosUsar();
			if(aux >= this.quantidade)
				return false;
		}
		return true;
	}
}
